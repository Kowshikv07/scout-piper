# nav_world — indoor environment for navigation + obstacle avoidance

## Layout
10 m x 8 m building, walls 2.5 m high:

- **Corridor** — horizontal strip through the middle (y ≈ -0.9 to 0.9), connects all rooms
- **Room A** (top-left) — sparse: 3 obstacles, good for an easy first training stage
- **Room B** (top-right) — cluttered: 7 obstacles of mixed shapes, for harder avoidance
- **Room C** (bottom) — large room holding the **target bottle** at `(2.2, -2.4)`
- Each room connects to the corridor through a 1.1 m doorway (robot-width dependent — widen in `generate_world.py` if your robot's footprint doesn't fit)

Obstacles are a mix of boxes and cylinders at varied sizes, rotations and non-grid positions, so a policy can't overfit to a repeating pattern.

## Files
- `worlds/nav_world.sdf` — the world. Install this into `<pkg>/share/<pkg>/worlds/`.
- `generate_world.py` — regenerate the world after editing room layout, obstacles, or the bottle's position (edit the `boxes` / `cylinders` / `BOTTLE_POS` lists near the top).
- `launch_world.py` — minimal launch file that starts Gazebo and bridges `/clock`.
- `layout_preview.png` — top-down reference image of this layout.

## Setup
1. Copy `worlds/nav_world.sdf` into `~/ros2_ws/src/my_robot/worlds/`.
2. Make sure your bottle model (`models/bottle/`) is on `GZ_SIM_RESOURCE_PATH`, since the world does:
   ```xml
   <include><uri>model://bottle</uri></include>
   ```
3. Add `worlds` to `data_files` in `setup.py` so colcon installs it, and `export GZ_SIM_RESOURCE_PATH=$GZ_SIM_RESOURCE_PATH:~/ros2_ws/src/my_robot/models` before launching.
4. Copy `launch_world.py` into `~/ros2_ws/src/my_robot/launch/`.
5. Build and launch:
   ```bash
   colcon build --packages-select my_robot
   source install/setup.bash
   ros2 launch my_robot launch_world.py
   ```
6. Spawn your robot separately (e.g. near the corridor entrance, `(-4.5, 0, 0.1)`) with your existing `ros_gz_sim create` call or spawn launch file — this world does not include a robot.

## Suggested robot spawn point
`(-4.5, 0.0, 0.1)`, yaw `0` — places it at the west end of the corridor, bottle is diagonally across the building through Room C, forcing it to traverse the corridor and avoid both corridor and room obstacles.

## Tuning
- **Doorway width**: `DOOR = 1.1` near the top of `generate_world.py`. Must exceed your robot's footprint plus clearance.
- **Obstacle density/difficulty**: add/remove entries in the `boxes` / `cylinders` lists per room. Keep Room A sparse as an "easy" curriculum stage if you're doing curriculum learning.
- **Lighting**: three point lights (one per room) plus a directional sun are included so the camera has usable contrast for YOLO — important since your bottle is mostly transparent.
- **Scale**: if 10x8 m is too large/small for your training time budget, scale all coordinates in `generate_world.py` uniformly (walls, obstacles, doors, bottle position together).
